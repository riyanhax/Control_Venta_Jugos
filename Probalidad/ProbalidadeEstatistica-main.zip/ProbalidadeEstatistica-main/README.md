# ProbalidadeEstatistica
Aulas e exercícios da matéria de Probabilidade e estatística em Python
